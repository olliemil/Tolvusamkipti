Assignment 1 - T-409-TSAM

# Table of content
- Master Readme.md -- wich is this readme file
- Assignment 1 TSAM.pdf
- ServerPart1-3 -- wich is the server.cpp used for part 1-3
- ClientPart3 -- wich is the orignal client.cpp before modifying
- ClientServerBsckdoorPart4 -- wich is the new server.cpp and client.cpp after modification